import 'dart:ui';

import 'package:flutter/material.dart';
import 'dart:math';

class Design extends CustomPainter {
  final Color color;
  final double lineHeight;
  final int maxLines;
  final int num;
  Design({this.color, this.lineHeight, this.maxLines,this.num});

  @override
  void paint(Canvas canvas, Size size) {
    final rad = size.width / 2;
    final Paint linePainter = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;
    canvas.translate(size.width / 2, size.height / 2);
    canvas.save();

    List.generate(maxLines , (i) {
      canvas.drawLine(Offset(0, rad), Offset(0, rad - num), linePainter);
      canvas.rotate(2 * pi / maxLines);
    });

    canvas.restore();
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}
