// Copyright 2019 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'dart:async';
import 'dart:ui';
import 'package:analog_clock/design.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_clock_helper/model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/semantics.dart';
import 'package:intl/intl.dart';
import 'package:vector_math/vector_math_64.dart' show radians;
import 'drawn_hand.dart';

final radiansPerTick = radians(360 / 60);
final radiansPerHour = radians(360 / 12);

class AnalogClock extends StatefulWidget {
  const AnalogClock(this.model);

  final ClockModel model;

  @override
  _AnalogClockState createState() => _AnalogClockState();
}

class _AnalogClockState extends State<AnalogClock>
    with SingleTickerProviderStateMixin {
  var _now = DateTime.now();
  var _temperature = '';
  var _temperatureRange = '';
  var _condition = '';
  var _location = '';
  Timer _timer;

  @override
  void initState() {
    super.initState();
    widget.model.addListener(_updateModel);

    _updateTime();
    _updateModel();
  }

  @override
  void didUpdateWidget(AnalogClock oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.model != oldWidget.model) {
      oldWidget.model.removeListener(_updateModel);
      widget.model.addListener(_updateModel);
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    widget.model.removeListener(_updateModel);
    super.dispose();
  }

  void _updateModel() {
    setState(() {
      _temperature = widget.model.temperatureString;
      _temperatureRange = '(${widget.model.low} - ${widget.model.highString})';
      _condition = widget.model.weatherString;
      _location = widget.model.location;
    });
  }

  void _updateTime() {
    setState(() {
      _now = DateTime.now();
      _timer = Timer(
        Duration(seconds: 1) - Duration(milliseconds: _now.millisecond),
        _updateTime,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final customTheme = Theme.of(context).brightness == Brightness.light
        ? Theme.of(context).copyWith(
            primaryColor: Colors.white70,
            highlightColor: Color(0xFF223651),
            accentColor: Color(0xFF669DF6),
            backgroundColor: Color(0xFFD2E3FC),
          )
        : Theme.of(context).copyWith(
            primaryColor: Colors.white70,
            highlightColor: Color(0xFF00001a),
            accentColor: Color(0xFF8AB4F8),
            backgroundColor: Color(0xFF3C4043),
          );

    final time = DateFormat.Hms().format(DateTime.now());
    final weatherInfo = DefaultTextStyle(
      style: TextStyle(color: customTheme.primaryColor),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _temperature,
            textAlign: TextAlign.center,
            textScaleFactor: 1.2,
            style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize:
                    MediaQuery.of(context).orientation == Orientation.landscape
                        ? 25
                        : 17),
          ),
          Text(_condition,
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: MediaQuery.of(context).orientation ==
                          Orientation.landscape
                      ? 25
                      : 17)),
          SizedBox(
            height: 5,
          ),
          Text(
            _location,
            textScaleFactor: 1.2,
            style: TextStyle(
                fontSize:
                    MediaQuery.of(context).orientation == Orientation.landscape
                        ? 13
                        : 10),
          ),
        ],
      ),
    );

    return Semantics.fromProperties(
      properties: SemanticsProperties(
        label: 'Analog clock with time $time',
        value: time,
      ),
      child: Container(
        decoration: BoxDecoration(
          color: customTheme.highlightColor,
        ),
        child: Stack(
          children: [
            Center(
              child: SizedBox(
                height:
                    MediaQuery.of(context).orientation == Orientation.landscape
                        ? 300
                        : 200,
                width:
                    MediaQuery.of(context).orientation == Orientation.landscape
                        ? 300
                        : 200,
                child: CustomPaint(
                  painter: Design(
                      lineHeight: 6,
                      maxLines: MediaQuery.of(context).orientation ==
                              Orientation.landscape
                          ? 80
                          : 60,
                      color: Theme.of(context).brightness == Brightness.light
                          ? Colors.teal
                          : Colors.greenAccent,
                      num: MediaQuery.of(context).orientation ==
                              Orientation.landscape
                          ? 25
                          : 20),
                ),
              ),
            ),
            DrawnHand(
              color: Colors.white70,
              thickness: 5,
              size: 0.48,
              angleRadians: _now.minute * radiansPerTick,
            ),
            DrawnHand(
              color: Colors.white30,
              thickness: 3.4,
              size: 0.67,
              angleRadians: _now.second * radiansPerTick,
            ),
            DrawnHand(
              color: Colors.white,
              thickness: 8.2,
              size: 0.32,
              angleRadians: _now.hour * radiansPerHour +
                  (_now.minute / 60) * radiansPerHour,
            ),
            Positioned(
              left: MediaQuery.of(context).orientation == Orientation.landscape
                  ? 175.7
                  : 110,
              bottom:
                  MediaQuery.of(context).orientation == Orientation.landscape
                      ? 120
                      : 70,
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: weatherInfo,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
